public class Aritmetica
{
    
    public Aritmetica()
    {
        System.out.println("Ejecutando constructor vacio");
    }
    
    public int sumar(int a, int b)
    {
        int resultado = a + b;
        return resultado;
    }
    
}
