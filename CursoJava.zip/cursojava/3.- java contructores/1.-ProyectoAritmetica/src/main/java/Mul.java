/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jma
 */
public class Mul {
    public Mul()
    {
        System.out.println("Ejecutando constructor vacio de mul....");
        
    }
    
    public int Multiplicar(int a, int b)
    {
        int resultado = a * b;
        return resultado;
    }
    
}
