package com.jm;

public class Utilerias 
{
  public static void imprimir(String s){
      System.out.println("s = "+ s);
  }
    
}
