//import com.jm.Utilerias;
public class Ejemplopaquetes {
    public static void main(String[] args) {
       com.jm.Utilerias.imprimir("hola");
    }
}
/*
import com.jm.Utilerias;
public class Ejemplopaquetes {
    public static void main(String[] args) {
      Utilerias.imprimir("hola");
    }
}
*/
// solo sirve para metodos estaticos
/*
import static com.jm.Utilerias.imprimir;
public class Ejemplopaquetes {
    public static void main(String[] args) {
      imprimir("hola");
    }
}*/
